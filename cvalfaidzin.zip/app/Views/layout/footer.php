<!-- Footer -->
<footer class="footer bg-dark text-white text-center py-3">
    &copy; <?= date('Y') ?> <?= esc($biodata['nama'] ?? 'Muchamad Alfaidzin') ?>. All Rights Reserved.
</footer>
